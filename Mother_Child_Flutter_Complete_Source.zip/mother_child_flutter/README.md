# Mother & Child Nutrition — Flutter + Dart

Conversion of the supplied Streamlit/Python project into Flutter UI, a reusable Dart core, a Dart AI gateway and a Dart CLI. No Python runtime is needed.

## Included features

- Separate Child and Mother profiles. Children: 0–215 completed months. Mothers: adult users 18–100 years; pregnant, breastfeeding, postpartum or other stage.
- Optional age, weight/length context (age is required); pregnancy weeks for pregnant mothers; diet, allergy and symptom notes.
- Gallery and camera input, photo preview/removal, supported-format and size checks, Android lost-photo recovery.
- English and Roman Urdu educational reports, food guidance, next steps, limitations and copy-to-clipboard.
- Offline guidance without an API key; optional Gemini through the included Dart gateway.
- Urgent-symptom guidance takes priority without waiting for AI.
- Session report history (last 10), manual clear, input validation, busy states, timeout/error handling and responsive mobile/web layout.
- Source tests, sample child/mother JSON profiles and native-platform bootstrap script.

## Important scope

This is an educational prototype, not a clinically validated medical device. The original code asked an AI to diagnose deficiencies and assign a risk score from a photograph. That behavior has deliberately been replaced: neither nutritional diagnosis nor deficiency severity/risk is reliably established by a photo. Measurements are recorded as context, not classified. No WHO growth z-score tables, lab inference, prescriptions or therapeutic feeding algorithm are implemented.

Offline mode does not interpret images, free-text notes or measurements. AI output is generated text that can be wrong and requires clinical review. Prompt instructions are not a clinical validation mechanism. The mother workflow is for adults; adolescent pregnancy needs a separate professionally reviewed pathway.

## Requirements

Install a current stable Flutter SDK with Dart >=3.6, then run `flutter doctor`. Use Android Studio/Android SDK for Android, Chrome for web, and macOS with Xcode for iOS. Package resolution may require a newer Dart/Flutter SDK depending on current compatible dependency releases.

The archive contains complete hand-written application and server source. Standard generated Android/iOS/web runner files are created with the included script using YOUR installed Flutter SDK. An APK/IPA or precompiled app is not included.

## Quick start: offline app

Open a terminal inside `mother_child_flutter`:

```sh
dart tool/bootstrap.dart
flutter pub get
flutter run -d chrome --web-port 5000
```

Or use `flutter run` to select an Android/iOS device. The script creates Android/iOS/web runner directories without replacing `lib`, `test` or `pubspec.yaml`. It adds Android internet access, debug-only HTTP permission and iOS camera/photo/local-network usage descriptions. Rerunning keeps existing runner directories and adds missing permission entries. Review generated native configuration for your installed SDK.

Select Child or Mother, enter the profile and press **Show offline guidance**. No photo is required. The Camera option on the web depends on browser/device support; gallery selection remains available. Test permissions on a real mobile device.

## Enable Gemini

The Gemini API key stays on the Dart server. The app receives only a private gateway access token entered at runtime in Settings. Never put the Gemini API key in Flutter assets, source or `--dart-define`.

1. Obtain a valid Gemini API key and select a currently available model supporting images, `generateContent` and structured JSON output. Set its exact identifier as `GEMINI_MODEL`; the model is intentionally configurable, not guessed from the original code.
2. Start the server in another terminal.

macOS/Linux:

```sh
cd server
dart pub get
export GEMINI_API_KEY='YOUR_KEY'
export GEMINI_MODEL='YOUR_AVAILABLE_VISION_MODEL'
export APP_ACCESS_TOKEN='YOUR_RANDOM_TOKEN_AT_LEAST_24_CHARACTERS'
export ALLOWED_ORIGIN='http://localhost:5000'
dart run bin/server.dart
```

Windows PowerShell:

```powershell
cd server
dart pub get
$env:GEMINI_API_KEY='YOUR_KEY'
$env:GEMINI_MODEL='YOUR_AVAILABLE_VISION_MODEL'
$env:APP_ACCESS_TOKEN='YOUR_RANDOM_TOKEN_AT_LEAST_24_CHARACTERS'
$env:ALLOWED_ORIGIN='http://localhost:5000'
dart run bin/server.dart
```

`server/.env.example` is documentation only; the server reads process environment variables and does not automatically load .env files. Do not use the placeholder token as a real secret.

3. Open app Settings and enter the URL and the same `APP_ACCESS_TOKEN`:

| Target | Gateway URL |
|---|---|
| Chrome on the server computer | `http://localhost:8080/analyze` |
| Android emulator | `http://10.0.2.2:8080/analyze` |
| iOS simulator or physical device | Use a reachable HTTPS gateway URL |

The gateway binds to loopback by default. For containers or a reachable private HTTPS deployment set `HOST=0.0.0.0` behind a TLS reverse proxy, with firewall and authentication controls. LAN HTTP URLs are intentionally rejected by the client. HTTPS pages cannot call an HTTP gateway because of mixed-content restrictions. Keep `ALLOWED_ORIGIN` equal to the exact web origin, including port; it does not authenticate native clients.

4. Turn on **Use AI gateway**, read and tick the consent box, then generate guidance. The selected profile, notes, measurements and optional image are sent to your gateway and Google Gemini. API access/quota/billing and provider data policies apply.

## CLI conversion

From `server`, after `dart pub get`:

```sh
# Without GEMINI_API_KEY this prints offline education:
dart run bin/cli_analyzer.dart ../docs/child_profile.json
dart run bin/cli_analyzer.dart ../docs/mother_profile.json
```

To call Gemini, set `GEMINI_API_KEY`, `GEMINI_MODEL` and `CONSENT_TO_AI=true` after consent. Then optionally include a photo:

```sh
dart run bin/cli_analyzer.dart ../docs/mother_profile.json /path/to/photo.jpg
```

Child age is in months; mother age is in years. JSON samples show the complete profile contract. Reports print as JSON. CLI errors return a nonzero exit code without echoing patient data or API secrets.

## Test and build

From the project root, after bootstrapping:

```sh
flutter analyze
flutter test
cd core
dart pub get
dart test
cd ../server
dart pub get
dart analyze
dart test
cd ..
flutter build web
flutter build apk --release
# macOS with Xcode and appropriate signing:
flutter build ios
```

Use HTTPS in Android release builds. Set production app identifiers and signing before distribution; the bootstrap uses `com.example`. Dependency lockfiles should be generated and committed after successful dependency resolution on your machine.

## Project map

| Original | Converted source |
|---|---|
| `app.py` + CSS | `lib/main.dart` (Material 3 Flutter UI) |
| `nutrition_analyzer.py` | `lib/api_client.dart`, `server/lib/gemini.dart`, `core/lib/nutrition_core.dart` |
| `cli_analyzer.py` | `server/bin/cli_analyzer.dart` |
| `requirements.txt` | root, core and server `pubspec.yaml` |
| `.env` / key UI | server environment + runtime gateway token settings |
| Child-only prompt | child + mother profiles and stage-aware education |

The uploaded Python virtual environment and original secret-bearing .env are not included. They are not application source and are not needed by Flutter.

## Privacy and deployment limits

No database, login system or persistent medical record store is included, matching the original session-based scope. Flutter keeps photos, token and reports in session memory, but operating-system image-picker caches and Google provider retention may exist. Clipboard copy is explicit and puts report text on the system clipboard. Profile switches clear the current image/form/report but do not delete session report history; use Clear reports to remove it.

The private gateway has a shared token, exact-origin CORS, 4 MB image limit, 6 MB request limit, 3-request concurrency cap and global 20-request/minute cap. These are development protections, not a production identity system. Before public use add per-user authorization, TLS, durable quotas, request cancellation/total ingress deadlines at the proxy, monitoring without patient payloads, privacy/consent review and professional clinical validation. The gateway does not intentionally log or store submitted payloads. File magic checks establish likely format, not full decoder validity; upstream failures are handled as errors.

## Validation status

This delivery was inspected and structurally checked, but Flutter/Dart are not installed in the authoring environment. The included Dart unit and Flutter widget tests have NOT been executed; no APK, iOS build, web build, camera/device test or live Gemini request has been verified. Run the commands above before relying on or distributing the app. See `docs/TESTING.md` for manual acceptance checks.

## References

- Flutter image picker: https://pub.dev/packages/image_picker
- Gemini REST generateContent: https://ai.google.dev/api/generate-content
- Gemini structured output: https://ai.google.dev/gemini-api/docs/structured-output
- Server-side API key handling: https://ai.google.dev/gemini-api/docs/api-key
- WHO child nutrition assessment: https://www.who.int/tools/elena/interventions/sam-identification
- WHO breastfeeding and complementary feeding: https://www.who.int/news-room/questions-and-answers/item/breastfeeding
- WHO pregnancy nutrition: https://www.who.int/tools/elena/interventions/nutrition-counselling-pregnancy
- WHO food during pregnancy/after childbirth: https://www.who.int/tools/your-life-your-health/life-phase/pregnancy--birth-and-after-childbirth/eating-healthy-food-during-pregnancy
