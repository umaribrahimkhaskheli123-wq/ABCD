import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mother_child_nutrition/main.dart';

void main() {
  testWidgets('switches child and mother forms', (tester) async {
    await tester.pumpWidget(const NutritionApp());
    expect(find.text('Age in completed months (0–215)'), findsOneWidget);
    await tester.tap(find.text('Mother'));
    await tester.pumpAndSettle();
    expect(find.text('Age in years (18–100)'), findsOneWidget);
    expect(find.text('Current stage'), findsOneWidget);
    await tester.tap(find.text('Child'));
    await tester.pumpAndSettle();
    expect(find.text('Current stage'), findsNothing);
  });
  testWidgets('offline generation renders education without a photo or key', (tester) async {
    await tester.pumpWidget(const NutritionApp());
    final generate = find.widgetWithText(FilledButton, 'Show offline guidance');
    await tester.ensureVisible(generate);
    await tester.tap(generate);
    await tester.pumpAndSettle();
    expect(find.text('Offline education • no image analysis'), findsOneWidget);
    expect(find.text('Child nutrition education'), findsOneWidget);
  });
}
