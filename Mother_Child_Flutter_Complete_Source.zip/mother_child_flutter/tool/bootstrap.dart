// Run from the project root: dart tool/bootstrap.dart
// Generates standard Flutter platform runners without replacing application code.
import 'dart:io';

Future<void> main() async {
  if (!File('pubspec.yaml').existsSync() || !Directory('core').existsSync()) {
    stderr.writeln('Run this script from the mother_child_flutter directory.'); exitCode = 1; return;
  }
  final temp = await Directory.systemTemp.createTemp('nutrition_platforms_');
  try {
    final result = await Process.run('flutter', ['create', '--no-pub', '--project-name', 'mother_child_nutrition',
      '--org', 'com.example', '--platforms=android,ios,web', temp.path], runInShell: Platform.isWindows);
    stdout.write(result.stdout); stderr.write(result.stderr);
    if (result.exitCode != 0) { exitCode = result.exitCode; return; }
    for (final name in ['android', 'ios', 'web']) {
      if (Directory(name).existsSync()) { stdout.writeln('Keeping existing $name directory.'); continue; }
      await copyTree(Directory('${temp.path}/$name'), Directory(name));
    }
    final metadata = File('${temp.path}/.metadata');
    if (!File('.metadata').existsSync() && metadata.existsSync()) await metadata.copy('.metadata');
    patchAndroid();
    patchIos();
    if (!Platform.isWindows && File('android/gradlew').existsSync()) await Process.run('chmod', ['+x', 'android/gradlew']);
    stdout.writeln('Platform runners ready. Run flutter pub get, flutter analyze, flutter test, then flutter run.');
  } finally { await temp.delete(recursive: true); }
}
Future<void> copyTree(Directory source, Directory target) async {
  await target.create(recursive: true);
  await for (final entity in source.list(followLinks: false)) {
    final name = entity.uri.pathSegments.where((s) => s.isNotEmpty).last;
    if (entity is Directory) await copyTree(entity, Directory('${target.path}/$name'));
    if (entity is File) await entity.copy('${target.path}/$name');
  }
}
void patchAndroid() {
  final file = File('android/app/src/main/AndroidManifest.xml');
  var text = file.readAsStringSync();
  if (!text.contains('android.permission.INTERNET')) {
    text = text.replaceFirst('<application', '<uses-permission android:name="android.permission.INTERNET"/>\n    <application');
  }
  file.writeAsStringSync(text);
  // Only debug permits HTTP to a local gateway; release stays HTTPS-only.
  final debug = File('android/app/src/debug/AndroidManifest.xml');
  debug.parent.createSync(recursive: true);
  var d = debug.existsSync() ? debug.readAsStringSync() : '<manifest xmlns:android="http://schemas.android.com/apk/res/android"></manifest>';
  if (!d.contains('usesCleartextTraffic')) {
    d = d.contains('<application') ? d.replaceFirst('<application', '<application android:usesCleartextTraffic="true"')
      : d.replaceFirst('</manifest>', '<application android:usesCleartextTraffic="true"/></manifest>');
  }
  debug.writeAsStringSync(d);
}
void patchIos() {
  final file = File('ios/Runner/Info.plist');
  var text = file.readAsStringSync();
  final fields = {
    'NSCameraUsageDescription': 'Take an optional nutrition consultation photo with your consent.',
    'NSPhotoLibraryUsageDescription': 'Choose an optional nutrition consultation photo with your consent.',
    'NSLocalNetworkUsageDescription': 'Connect to your private development nutrition gateway.',
  };
  for (final entry in fields.entries) {
    if (!text.contains('<key>${entry.key}</key>')) {
      final index = text.lastIndexOf('</dict>');
      text = text.substring(0, index) + '<key>${entry.key}</key>\n<string>${entry.value}</string>\n' + text.substring(index);
    }
  }
  file.writeAsStringSync(text);
}
