import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:nutrition_core/nutrition_core.dart';
import 'api_client.dart';

void main() => runApp(const NutritionApp());

class NutritionApp extends StatelessWidget {
  const NutritionApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Mother & Child Nutrition', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff16786d)),
      scaffoldBackgroundColor: const Color(0xfff4f8f7),
      inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder(), filled: true, fillColor: Colors.white)),
    home: const NutritionHome());
}

class NutritionHome extends StatefulWidget {
  const NutritionHome({super.key});
  @override
  State<NutritionHome> createState() => _NutritionHomeState();
}

class _NutritionHomeState extends State<NutritionHome> {
  final _form = GlobalKey<FormState>();
  final _age = TextEditingController(text: '24');
  final _weeks = TextEditingController();
  final _weight = TextEditingController();
  final _height = TextEditingController();
  final _notes = TextEditingController();
  final _picker = ImagePicker();
  PersonType _type = PersonType.child;
  MaternalStage _stage = MaternalStage.other;
  String _sex = 'unspecified';
  bool _ai = false, _consent = false, _urgent = false, _busy = false;
  Uint8List? _image;
  String? _mime, _error;
  NutritionReport? _report;
  final List<NutritionReport> _history = [];
  String _endpoint = const String.fromEnvironment('API_URL', defaultValue: 'http://localhost:8080/analyze');
  String _token = '';

  @override
  void initState() { super.initState(); _recoverImage(); }
  @override
  void dispose() {
    for (final c in [_age, _weeks, _weight, _height, _notes]) { c.dispose(); }
    super.dispose();
  }
  Future<void> _recoverImage() async {
    if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) return;
    try {
      final result = await _picker.retrieveLostData();
      if (result.files?.isNotEmpty == true) await _acceptImage(result.files!.first);
      if (result.exception != null && mounted) setState(() => _error = 'Could not recover the previous photo. Please select it again.');
    } catch (_) { /* Recovery is optional; the picker remains available. */ }
  }
  Future<void> _acceptImage(XFile f) async {
    if (await f.length() > 4 * 1024 * 1024) throw const FormatException('Choose a photo smaller than 4 MB.');
    final bytes = await f.readAsBytes();
    final mime = detectImageMime(bytes);
    if (mime == null) throw const FormatException('Choose a JPG, PNG or WebP image.');
    if (mounted) setState(() { _image = bytes; _mime = mime; _report = null; _consent = false; });
  }
  Future<void> _pick(ImageSource source) async {
    setState(() { _busy = true; _error = null; });
    try {
      final f = await _picker.pickImage(source: source, maxWidth: 1600, maxHeight: 1600, imageQuality: 85);
      if (f != null) await _acceptImage(f);
    } on FormatException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Could not open the camera or gallery. Check permissions or select another image.');
    } finally { if (mounted) setState(() => _busy = false); }
  }
  void _switchType(PersonType v) {
    setState(() {
      _type = v; _age.text = v == PersonType.child ? '24' : '28';
      _weeks.clear(); _weight.clear(); _height.clear(); _notes.clear();
      _stage = MaternalStage.other; _sex = 'unspecified';
      _image = null; _mime = null; _report = null; _error = null; _urgent = false; _consent = false;
    });
  }
  Future<void> _analyze() async {
    if (!_form.currentState!.validate()) return;
    if (_ai && !_urgent && !_consent) { setState(() => _error = 'Please consent before sending information to the gateway and Google Gemini.'); return; }
    setState(() { _busy = true; _error = null; _report = null; });
    try {
      final p = Profile(type: _type, age: int.parse(_age.text.trim()), sex: _sex,
        stage: _stage, pregnancyWeeks: _type == PersonType.mother && _stage == MaternalStage.pregnant && _weeks.text.trim().isNotEmpty ? int.parse(_weeks.text.trim()) : null,
        weightKg: double.tryParse(_weight.text.trim()), heightCm: double.tryParse(_height.text.trim()),
        notes: _notes.text.trim(), urgentSymptoms: _urgent);
      p.validate();
      // An urgent flag always takes precedence over remote AI.
      final r = _urgent || !_ai ? educationFor(p) : await NutritionApi.analyze(
        endpoint: _endpoint, token: _token, profile: p, image: _image, mime: _mime);
      if (mounted) setState(() { _report = r; _history.insert(0, r); if (_history.length > 10) _history.removeLast(); });
    } on FormatException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'Unable to complete this request. Check your connection and gateway, or use offline education.');
    } finally { if (mounted) setState(() => _busy = false); }
  }
  Future<void> _settings() async {
    final url = TextEditingController(text: _endpoint);
    final token = TextEditingController(text: _token);
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('AI gateway settings'),
      content: SizedBox(width: 480, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Run the included Dart gateway first. Your Gemini API key stays on the server. Settings and access token are kept only for this session.'),
        const SizedBox(height: 16), TextField(controller: url, decoration: const InputDecoration(labelText: 'Gateway /analyze URL')),
        const SizedBox(height: 16), TextField(controller: token, obscureText: true, decoration: const InputDecoration(labelText: 'Gateway access token (not Gemini key)')),
      ]))), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () { setState(() { _endpoint = url.text.trim(); _token = token.text.trim(); _consent = false; }); Navigator.pop(ctx); }, child: const Text('Save'))]));
    await Future<void>.delayed(const Duration(milliseconds: 350));
    url.dispose(); token.dispose();
  }
  void _showHistory() => showDialog<void>(context: context, builder: (ctx) => AlertDialog(
    title: const Text('Session reports'), content: SizedBox(width: 480, child: _history.isEmpty
      ? const Text('No reports yet. Reports disappear when this app session ends.')
      : ListView(shrinkWrap: true, children: [for (final r in _history) ListTile(title: Text(r.summary), subtitle: Text(r.source),
          onTap: () { setState(() => _report = r); Navigator.pop(ctx); })])),
    actions: [TextButton(onPressed: () { setState(() { _history.clear(); _report = null; }); Navigator.pop(ctx); }, child: const Text('Clear reports')),
      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))]));

  Widget _number(TextEditingController c, String label, {bool required = false, bool integer = false, double min = 0, double max = 500}) => Padding(
    padding: const EdgeInsets.only(bottom: 14), child: TextFormField(controller: c,
      keyboardType: TextInputType.numberWithOptions(decimal: !integer), decoration: InputDecoration(labelText: label),
      validator: (value) {
        final text = value?.trim() ?? '';
        if (text.isEmpty) return required ? 'This field is required.' : null;
        final v = integer ? int.tryParse(text)?.toDouble() : double.tryParse(text);
        return v == null || !v.isFinite || v < min || v > max ? 'Enter ${integer ? 'a whole number' : 'a number'} between $min and $max.' : null;
      }));
  Widget _section(String title, List<Widget> children) => Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(22),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Text(title, style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 18), ...children])));

  Widget _inputs() => Form(key: _form, child: Column(children: [
    _section('1. Choose a profile', [
      SegmentedButton<PersonType>(segments: const [ButtonSegment(value: PersonType.child, icon: Icon(Icons.child_care), label: Text('Child')),
        ButtonSegment(value: PersonType.mother, icon: Icon(Icons.person), label: Text('Mother'))],
        selected: {_type}, onSelectionChanged: (v) => _switchType(v.first)),
      const SizedBox(height: 20),
      _number(_age, _type == PersonType.child ? 'Age in completed months (0–215)' : 'Age in years (18–100)', required: true, integer: true,
        min: _type == PersonType.child ? 0 : 18, max: _type == PersonType.child ? 215 : 100),
      if (_type == PersonType.child) DropdownButtonFormField<String>(value: _sex, decoration: const InputDecoration(labelText: 'Sex (optional)'),
        items: const [DropdownMenuItem(value: 'unspecified', child: Text('Not specified')), DropdownMenuItem(value: 'female', child: Text('Female')),
          DropdownMenuItem(value: 'male', child: Text('Male'))], onChanged: (v) => setState(() => _sex = v!)),
      if (_type == PersonType.mother) DropdownButtonFormField<MaternalStage>(value: _stage, decoration: const InputDecoration(labelText: 'Current stage'),
        items: [for (final v in MaternalStage.values) DropdownMenuItem(value: v, child: Text(v.name))],
        onChanged: (v) => setState(() { _stage = v!; _weeks.clear(); })),
      const SizedBox(height: 14),
      if (_type == PersonType.mother && _stage == MaternalStage.pregnant)
        _number(_weeks, 'Pregnancy weeks (optional)', integer: true, min: 1, max: 42),
      _number(_weight, 'Weight in kg (optional)', min: 0.1),
      _number(_height, 'Height / length in cm (optional)', min: 20, max: 250),
      TextFormField(controller: _notes, maxLength: 2000, maxLines: 3,
        decoration: const InputDecoration(labelText: 'Diet, symptoms and allergies (optional)', helperText: 'Do not include names or contact details.')),
      const SizedBox(height: 8),
      CheckboxListTile(contentPadding: EdgeInsets.zero, value: _urgent,
        title: const Text('Urgent symptoms are present'),
        subtitle: const Text('For example: severe breathing difficulty, inability to drink/feed, unconsciousness, seizures, or heavy bleeding.'),
        onChanged: (v) => setState(() => _urgent = v!)),
      if (_urgent) const Card(color: Color(0xffffe5df), child: Padding(padding: EdgeInsets.all(14), child: Text(urgentMessage))),
    ]),
    _section('2. Optional photo', [
      const Text('Photos cannot diagnose deficiencies. In offline mode, photos stay on this device and are not analyzed.'), const SizedBox(height: 14),
      if (_image != null) ...[ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(_image!, height: 220, fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => const Text('Unable to preview image; choose another photo.'))),
        TextButton.icon(onPressed: () => setState(() { _image = null; _mime = null; _consent = false; }), icon: const Icon(Icons.delete_outline), label: const Text('Remove photo'))],
      Wrap(spacing: 12, runSpacing: 8, children: [OutlinedButton.icon(onPressed: () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('Gallery')),
        OutlinedButton.icon(onPressed: () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt_outlined), label: const Text('Camera'))]),
    ]),
    _section('3. Generate guidance', [
      SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Use AI gateway'), subtitle: const Text('Off = offline educational guidance. No account or key needed.'),
        value: _ai, onChanged: (v) => setState(() { _ai = v; _consent = false; _report = null; })),
      if (_ai) CheckboxListTile(contentPadding: EdgeInsets.zero, value: _consent,
        title: const Text('I consent to sending the profile, notes and optional photo to the configured gateway and Google Gemini.'),
        subtitle: const Text('I am the adult subject or authorized parent/guardian. Provider data policies apply.'), onChanged: (v) => setState(() => _consent = v!)),
      FilledButton.icon(onPressed: _analyze, icon: const Icon(Icons.auto_awesome_outlined),
        label: Text(_urgent ? 'Show urgent-care guidance' : _ai ? 'Generate AI guidance' : 'Show offline guidance')),
    ]),
  ]));

  Widget _results() => _section('Nutrition report', [
    if (_busy) ...[const LinearProgressIndicator(), const SizedBox(height: 16), const Text('Please wait…')],
    if (_error != null) ...[Text(_error!, style: const TextStyle(color: Colors.red)), const SizedBox(height: 16)],
    if (_report == null && !_busy) const Text('Choose Child or Mother and generate guidance. Your report will appear here.'),
    if (_report != null) ...[
      Text(_report!.source, style: TextStyle(color: Theme.of(context).colorScheme.primary)), const SizedBox(height: 12),
      Text(_report!.summary, style: Theme.of(context).textTheme.headlineSmall), const SizedBox(height: 18),
      const Text('Roman Urdu summary', style: TextStyle(fontWeight: FontWeight.bold)), Text(_report!.romanUrdu), const SizedBox(height: 18),
      for (final entry in {'Food guidance': _report!.foods, 'Next steps': _report!.nextSteps, 'Limitations': _report!.limitations}.entries) ...[
        Text(entry.key, style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 8),
        for (final item in entry.value) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text('• $item')),
        const SizedBox(height: 12)],
      OutlinedButton.icon(onPressed: () async {
        await Clipboard.setData(ClipboardData(text: _report!.text));
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Report copied. Clipboard contents may be visible to other apps.')));
      }, icon: const Icon(Icons.copy), label: const Text('Copy report')),
    ],
  ]);

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Mother & Child Nutrition'), actions: [
      IconButton(tooltip: 'Session reports', onPressed: _busy ? null : _showHistory, icon: const Icon(Icons.history)),
      IconButton(tooltip: 'Settings', onPressed: _busy ? null : _settings, icon: const Icon(Icons.settings_outlined))]),
    body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Center(child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 1200), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Padding(padding: const EdgeInsets.fromLTRB(8, 12, 8, 20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Nutrition support for two generations', style: Theme.of(context).textTheme.headlineMedium), const SizedBox(height: 10), const Text(disclaimer)])),
        LayoutBuilder(builder: (context, constraints) => constraints.maxWidth >= 860
          ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: AbsorbPointer(absorbing: _busy, child: _inputs())), const SizedBox(width: 16), Expanded(child: _results())])
          : Column(children: [AbsorbPointer(absorbing: _busy, child: _inputs()), _results()])),
        const Padding(padding: EdgeInsets.all(16), child: Text('Session-only data • No diagnosis • No automated deficiency or risk scores')),
      ]))))));
}
