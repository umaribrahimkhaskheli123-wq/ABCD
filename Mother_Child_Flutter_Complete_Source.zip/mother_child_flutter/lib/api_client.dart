import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'package:nutrition_core/nutrition_core.dart';

class NutritionApi {
  static Future<NutritionReport> analyze({required String endpoint, required String token,
    required Profile profile, Uint8List? image, String? mime}) async {
    final uri = Uri.tryParse(endpoint.trim());
    if (uri == null || uri.host.isEmpty || uri.userInfo.isNotEmpty || uri.hasQuery || uri.hasFragment ||
        !(uri.scheme == 'https' || (uri.scheme == 'http' && ['localhost', '127.0.0.1', '10.0.2.2'].contains(uri.host)))) {
      throw const FormatException('Use an HTTPS gateway URL, or HTTP on localhost/Android emulator for development.');
    }
    if (token.trim().isEmpty) throw const FormatException('Enter your gateway access token.');
    final client = http.Client();
    try {
      final r = await client.post(uri, headers: {'Content-Type': 'application/json',
        'Authorization': 'Bearer ${token.trim()}'}, body: jsonEncode({
          'profile': profile.toJson(), 'consent': true,
          if (image != null) 'image': {'mime': mime, 'data': base64Encode(image)},
        })).timeout(const Duration(seconds: 75));
      if (r.statusCode == 401) throw const FormatException('Gateway token rejected. Check Settings.');
      if (r.statusCode == 429) throw const FormatException('Gateway busy. Please try again later.');
      if (r.statusCode != 200) throw FormatException('Request failed (${r.statusCode}). Check the gateway configuration or try again.');
      final data = jsonDecode(r.body) as Map<String, dynamic>;
      return NutritionReport.fromJson(data, trustedSource: 'AI-generated education • verify with a clinician');
    } on TimeoutException {
      throw const FormatException('The request timed out. Please try again.');
    } finally { client.close(); }
  }
}
