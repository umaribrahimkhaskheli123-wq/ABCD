import 'dart:typed_data';
import 'package:test/test.dart';
import 'package:nutrition_core/nutrition_core.dart';

void main() {
  test('child and mother profiles round trip', () {
    for (final p in [const Profile(type: PersonType.child, age: 0),
      const Profile(type: PersonType.mother, age: 28, stage: MaternalStage.pregnant, pregnancyWeeks: 20)]) {
      expect(Profile.fromJson(p.toJson()).toJson(), p.toJson());
    }
  });
  test('child age bounds and maternal adult-only scope', () {
    for (final p in [const Profile(type: PersonType.child, age: -1),
      const Profile(type: PersonType.child, age: 216), const Profile(type: PersonType.mother, age: 17)]) {
      expect(p.validate, throwsFormatException);
    }
  });
  test('rejects non-finite measurements and incompatible pregnancy fields', () {
    expect(const Profile(type: PersonType.child, age: 12, weightKg: double.nan).validate, throwsFormatException);
    expect(const Profile(type: PersonType.child, age: 12, pregnancyWeeks: 20).validate, throwsFormatException);
    expect(const Profile(type: PersonType.mother, age: 28, stage: MaternalStage.pregnant, pregnancyWeeks: 43).validate, throwsFormatException);
  });
  test('six-month boundary changes feeding education', () {
    final infant = educationFor(const Profile(type: PersonType.child, age: 5));
    final older = educationFor(const Profile(type: PersonType.child, age: 6));
    expect(infant.foods.first, contains('exclusive breastfeeding'));
    expect(older.foods.first, contains('complementary foods'));
  });
  test('mother stages have separate guidance', () {
    final pregnant = educationFor(const Profile(type: PersonType.mother, age: 28, stage: MaternalStage.pregnant));
    final feeding = educationFor(const Profile(type: PersonType.mother, age: 28, stage: MaternalStage.breastfeeding));
    expect(pregnant.foods.join(), contains('antenatal'));
    expect(feeding.foods.join(), contains('breastfeeding'));
  });
  test('urgent symptoms take priority in next steps', () {
    final r = educationFor(const Profile(type: PersonType.child, age: 12, urgentSymptoms: true));
    expect(r.nextSteps.first, urgentMessage);
  });
  test('report roundtrip and malformed provider data', () {
    final r = educationFor(const Profile(type: PersonType.child, age: 24));
    expect(NutritionReport.fromJson(r.toJson()).text, r.text);
    expect(() => NutritionReport.fromJson({...r.toJson(), 'foods': [123]}), throwsFormatException);
    expect(() => NutritionReport.fromJson({...r.toJson(), 'summary': ''}), throwsFormatException);
  });
  test('image signature validation rejects disguised text', () {
    expect(detectImageMime(Uint8List.fromList(List.filled(16, 65))), isNull);
    expect(detectImageMime(Uint8List.fromList([255,216,255,...List.filled(9,0)])), 'image/jpeg');
    expect(detectImageMime(Uint8List.fromList([137,80,78,71,13,10,26,10,0,0,0,0])), 'image/png');
  });
}
