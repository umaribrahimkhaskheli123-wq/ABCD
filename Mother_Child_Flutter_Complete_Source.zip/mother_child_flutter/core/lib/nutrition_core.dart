import 'dart:convert';
import 'dart:typed_data';

enum PersonType { child, mother }
enum MaternalStage { pregnant, breastfeeding, postpartum, other }

class Profile {
  final PersonType type;
  // Children: completed months; mothers: completed years.
  final int age;
  final String sex;
  final MaternalStage stage;
  final int? pregnancyWeeks;
  final double? weightKg, heightCm;
  final String notes;
  final bool urgentSymptoms;
  const Profile({required this.type, required this.age, this.sex = 'unspecified',
    this.stage = MaternalStage.other, this.pregnancyWeeks, this.weightKg,
    this.heightCm, this.notes = '', this.urgentSymptoms = false});

  void validate() {
    if (age < 0 || (type == PersonType.child ? age > 215 : age < 18 || age > 100)) {
      throw const FormatException('Child age must be 0–215 months; mother age must be 18–100 years.');
    }
    if (!['female', 'male', 'unspecified'].contains(sex)) {
      throw const FormatException('Invalid sex selection.');
    }
    if (pregnancyWeeks != null && (pregnancyWeeks! < 1 || pregnancyWeeks! > 42)) {
      throw const FormatException('Pregnancy weeks must be 1–42.');
    }
    if (pregnancyWeeks != null && (type != PersonType.mother || stage != MaternalStage.pregnant)) {
      throw const FormatException('Pregnancy weeks apply only to a pregnant mother.');
    }
    if (weightKg != null && (!weightKg!.isFinite || weightKg! <= 0 || weightKg! > 500)) {
      throw const FormatException('Enter a valid weight in kg.');
    }
    if (heightCm != null && (!heightCm!.isFinite || heightCm! < 20 || heightCm! > 250)) {
      throw const FormatException('Enter a valid height/length in cm.');
    }
    if (notes.length > 2000) throw const FormatException('Notes must be 2000 characters or fewer.');
  }
  Map<String, dynamic> toJson() => {
    'type': type.name, 'age': age, 'age_unit': type == PersonType.child ? 'months' : 'years',
    'sex': sex, 'stage': type == PersonType.mother ? stage.name : null,
    'pregnancy_weeks': pregnancyWeeks, 'weight_kg': weightKg,
    'height_cm': heightCm, 'notes': notes, 'urgent_symptoms': urgentSymptoms,
  };
  factory Profile.fromJson(Map<String, dynamic> j) {
    if (j['age'] is! int || j['urgent_symptoms'] is! bool || j['notes'] is! String ||
        !PersonType.values.any((v) => v.name == j['type'])) {
      throw const FormatException('Invalid profile fields.');
    }
    final type = PersonType.values.byName(j['type'] as String);
    if (type == PersonType.mother && !MaternalStage.values.any((v) => v.name == j['stage'])) {
      throw const FormatException('Invalid maternal stage.');
    }
    final p = Profile(type: type, age: j['age'] as int,
      sex: j['sex'] as String? ?? 'unspecified',
      stage: type == PersonType.mother ? MaternalStage.values.byName(j['stage'] as String) : MaternalStage.other,
      pregnancyWeeks: j['pregnancy_weeks'] as int?,
      weightKg: (j['weight_kg'] as num?)?.toDouble(), heightCm: (j['height_cm'] as num?)?.toDouble(),
      notes: j['notes'] as String, urgentSymptoms: j['urgent_symptoms'] as bool);
    p.validate();
    return p;
  }
}

String? detectImageMime(Uint8List bytes) {
  if (bytes.length < 12) return null;
  if (bytes[0] == 255 && bytes[1] == 216 && bytes[2] == 255) return 'image/jpeg';
  if (bytes[0] == 137 && bytes[1] == 80 && bytes[2] == 78 && bytes[3] == 71 &&
      bytes[4] == 13 && bytes[5] == 10 && bytes[6] == 26 && bytes[7] == 10) return 'image/png';
  if (ascii.decode(bytes.sublist(0, 4), allowInvalid: true) == 'RIFF' &&
      ascii.decode(bytes.sublist(8, 12), allowInvalid: true) == 'WEBP') return 'image/webp';
  return null;
}

const disclaimer = 'Educational guidance only. Photos cannot confirm nutritional status, anaemia or vitamin deficiencies. Clinical history, examination, growth measurements and sometimes laboratory tests are needed. This app is not a diagnosis or treatment plan.';
const urgentMessage = 'You reported urgent symptoms. Seek urgent in-person medical care now; do not wait for an AI report. For severe breathing difficulty, unconsciousness, seizures or heavy bleeding, contact local emergency services.';

class NutritionReport {
  final String source, summary, romanUrdu;
  final List<String> foods, nextSteps, limitations;
  const NutritionReport({required this.source, required this.summary,
    required this.romanUrdu, required this.foods, required this.nextSteps, required this.limitations});
  Map<String, dynamic> toJson() => {'source': source, 'summary': summary,
    'summary_urdu_roman': romanUrdu, 'foods': foods, 'next_steps': nextSteps, 'limitations': limitations};
  factory NutritionReport.fromJson(Map<String, dynamic> j, {String? trustedSource}) {
    String field(String key) {
      final v = j[key];
      if (v is! String || v.trim().isEmpty || v.length > 6000) throw FormatException('Invalid report field: $key');
      return v;
    }
    List<String> items(String key) {
      final v = j[key];
      if (v is! List || v.isEmpty || v.length > 20 || v.any((s) => s is! String || s.length > 2000)) {
        throw FormatException('Invalid report list: $key');
      }
      return v.cast<String>();
    }
    return NutritionReport(source: trustedSource ?? field('source'), summary: field('summary'),
      romanUrdu: field('summary_urdu_roman'), foods: items('foods'),
      nextSteps: items('next_steps'), limitations: items('limitations'));
  }
  String get text => '$source\n\n$summary\n\nRoman Urdu\n$romanUrdu\n\nFood guidance\n${foods.join('\n')}\n\nNext steps\n${nextSteps.join('\n')}\n\nLimitations\n${limitations.join('\n')}\n\n$disclaimer';
}

NutritionReport educationFor(Profile p) {
  p.validate();
  final child = p.type == PersonType.child;
  final infant = child && p.age < 6;
  final foods = infant
    ? ['For babies under 6 months, WHO recommends exclusive breastfeeding. If breastfeeding is not possible or feeding is difficult, discuss a safe feeding plan with a qualified health worker.',
       'Do not start solid foods from a photo assessment. Ask a clinician about feeding and growth concerns.']
    : child
      ? ['From 6 months, introduce age-appropriate complementary foods alongside continued breastfeeding when applicable.',
         'Offer varied foods such as lentils, well-cooked eggs, vegetables, fruit and suitable dairy; adapt textures and portions to age.',
         'Avoid choking hazards such as whole nuts for young children. Account for known food allergies and prepare food safely.']
      : ['Choose varied meals with vegetables, fruit, whole grains, lentils/beans and suitable protein foods.',
         'Use clean, safely prepared foods and pasteurized dairy. Account for allergies and clinician-advised restrictions.',
         if (p.stage == MaternalStage.pregnant) 'Discuss pregnancy nutrition and supplements with your antenatal team; this app does not prescribe doses.',
         if (p.stage == MaternalStage.breastfeeding) 'Continue a varied diet while breastfeeding and ask for feeding support if needed.'];
  return NutritionReport(source: 'Offline education • no image analysis',
    summary: infant ? 'Infant feeding and growth support' : child ? 'Child nutrition education' : 'Mother nutrition education — ${p.stage.name}',
    romanUrdu: 'Yeh sirf aam ghizai maloomat hain. Tasweer se khoon ya vitamins ki kami ki tashkhees nahi ho sakti. Apni ya bachay ki sehat ke liye qualified doctor se mashwara karein.',
    foods: foods, nextSteps: [if (p.urgentSymptoms) urgentMessage,
      child ? 'Arrange a growth and feeding review with a child health professional if concerned.' : 'Discuss nutrition concerns with your doctor or midwife, including any pregnancy or breastfeeding needs.',
      'Bring recent weight/height records, symptoms, diet history and current medicines or supplements.',
      'Do not start iron, high-dose vitamins or therapeutic feeding on the basis of this app.'],
    limitations: [disclaimer, 'Offline mode does not interpret photos, free-text notes or measurements, and does not assign a risk score.']);
}
