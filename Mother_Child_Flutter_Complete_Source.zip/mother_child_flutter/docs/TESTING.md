# Acceptance checks (run after installing Flutter)

1. Run the automated commands in README; record Flutter/Dart versions and results.
2. Child: age 0, 5, 6 and 215 months work; -1, 216, decimals and blank fail. Under 6 months has infant-feeding guidance.
3. Mother: choose all four stages. Pregnancy-week field appears only for pregnant and clears on stage change. Ages below 18 are rejected.
4. Enter NaN, Infinity, negative weight, invalid height and overlong notes; invalid numeric input must fail.
5. Generate offline reports without a photo/network/API key. Confirm report explicitly says no image analysis.
6. Upload JPG/PNG/WebP; cancel a picker; deny camera permission; try unsupported and >4 MB files. Retry and remove photo.
7. Switch profile: current photo, notes and consent clear. Previous reports remain only in session history until cleared.
8. Urgent symptoms show immediate guidance; Generate must not contact the AI gateway.
9. AI consent must be required. Wrong token fails; unavailable gateway/model/quota and blocked/malformed AI output show errors, never a fake success.
10. Check valid Gemini output for both profiles; verify no diagnosis or invented risk scores, supplement doses or infant solids advice. Clinician review is still required; model output cannot be guaranteed by a prompt.
11. Review small-screen and wide-screen layout, keyboard scrolling, report copy, history clear and app restart behavior.
12. Check Android gallery/camera permission handling and lost-data recovery on device; test iOS permission descriptions and HTTPS connectivity.
13. Gateway: missing secrets refuse startup; missing consent, wrong method, bad origin, oversized input, mismatched image type and malformed profile are rejected; check rate/concurrency limits.
14. Build release targets and review platform identifiers, HTTPS, signing and provider privacy settings before distribution.
