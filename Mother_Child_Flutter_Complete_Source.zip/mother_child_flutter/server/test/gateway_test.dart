import 'package:test/test.dart';
import 'package:nutrition_core/nutrition_core.dart';
import 'package:nutrition_gateway/gemini.dart';

void main() {
  test('urgent flags never call upstream, even with empty credentials', () async {
    final r = await generateEducation(profile: const Profile(type: PersonType.mother, age: 30, urgentSymptoms: true), key: '', model: '');
    expect(r.nextSteps.first, urgentMessage);
    expect(r.source, contains('Offline'));
  });
  test('invalid model names rejected before networking', () async {
    await expectLater(generateEducation(profile: const Profile(type: PersonType.child, age: 24), key: 'test', model: '../bad'), throwsFormatException);
  });
}
